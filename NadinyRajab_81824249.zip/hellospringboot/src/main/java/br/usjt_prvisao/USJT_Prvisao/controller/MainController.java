package br.usjt_prvisao.USJT_Prvisao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.usjt_prvisao.USJT_Prvisao.model.Previsao;
import br.usjt_prvisao.USJT_Prvisao.repository.PrevisaoRepo;

@Controller
public class MainController {
	@Autowired
	private PrevisaoRepo previsaoRepo;

	@GetMapping("/home")
	public ModelAndView listarPrevisao() {
		ModelAndView mv = new ModelAndView("home");
		List<Previsao> previsao = previsaoRepo.findAll();
		mv.addObject("previsao",previsao);
		return mv;
	}
}
